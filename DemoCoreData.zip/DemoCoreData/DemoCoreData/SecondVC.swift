//
//  SecondVC.swift
//  DemoCoreData
//
//  Created by student on 16/10/23.
//  Copyright © 2023 student. All rights reserved.
//

import UIKit
import CoreData

class SecondVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    @IBOutlet weak var myTableView: UITableView!
    var ArrStudent=[NSManagedObject]()
    var appdelegate=UIApplication.shared.delegate as! AppDelegate
    var count=0
    var editindex=0
    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        
        return ArrStudent.count
    }
    
    
    @available(iOS 2.0, *)
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        
        print(ArrStudent.count)
        
        var Single=ArrStudent[indexPath.row]
        let DetailINfo=Single.value(forKey: "roll")
        
        let cell=UITableViewCell(style: .subtitle, reuseIdentifier: "MyCell")
        cell.textLabel?.text=Single.value(forKey: "name") as! String
        
        
        var converInt=Single.value(forKey: "roll") as! Int
        var converString=String(converInt)
        cell.detailTextLabel?.text=converString
        
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        editindex=indexPath.row
        performSegue(withIdentifier: "WayToEditData", sender: self)
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let DestVC=segue.destination as! EditStudentVC
        DestVC.inde=editindex
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        var contex=appdelegate.persistentContainer.viewContext
        
        contex.delete(ArrStudent[indexPath.row])
        ArrStudent.remove(at: indexPath.row)
        
        do {
            try contex.save()
        } catch let Error as NSError {
            print(Error)
        }
        
        tableView.reloadData()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var contex=appdelegate.persistentContainer.viewContext
        let FetchRequest=NSFetchRequest<NSManagedObject>(entityName: "Student")
        
        
        do {
            ArrStudent=try contex.fetch(FetchRequest)
        } catch let Error as NSError {
            print(Error)
        }
        
        /*var contex=appdelegate.persistentContainer.viewContext
        var ArrStudent=[NSManagedObject]()
        let FetchRequest=NSFetchRequest<NSManagedObject>(entityName: "Student")
        
        
        do {
            ArrStudent=try contex.fetch(FetchRequest)
        } catch let Error as NSError {
            print(Error)
        }
        print(ArrStudent.count)
        print(ArrStudent[0].value(forKey: "name"))
        print(ArrStudent[0].value(forKey: "roll"))*/
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        myTableView.reloadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
