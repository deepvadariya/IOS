//
//  EditStudentVC.swift
//  DemoCoreData
//
//  Created by student on 23/10/23.
//  Copyright © 2023 student. All rights reserved.
//

import UIKit
import CoreData

class EditStudentVC: UIViewController {
    
    var inde=0
    var ArrStudent=[NSManagedObject]()
    @IBOutlet weak var StudentNamelbl: UITextField!
    @IBOutlet weak var StudentRolllbl: UITextField!
    var appdel=UIApplication.shared.delegate as! AppDelegate
    
    @IBAction func StudentEditbtn(_ sender: Any) {
        
        var contex=appdel.persistentContainer.viewContext
        
        var StudentEntity=NSEntityDescription.entity(forEntityName: "Student", in: contex)
        
        let NewStudent=ArrStudent[inde].self
        
        NewStudent.setValue(StudentNamelbl.text, forKey: "name")
        NewStudent.setValue(Int(StudentRolllbl.text!), forKey: "roll")
        
        do {
            try contex.save()
        } catch let Error as NSError {
            print(Error)
        }
        self.navigationController?.popViewController(animated: true)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        var contex=appdel.persistentContainer.viewContext
        let FetchRequest=NSFetchRequest<NSManagedObject>(entityName: "Student")
        
        
        do {
            ArrStudent=try contex.fetch(FetchRequest)
        } catch let Error as NSError {
            print(Error)
        }
        StudentNamelbl.text=ArrStudent[inde].value(forKey: "name") as! String
        var converInt=ArrStudent[inde].value(forKey: "roll") as! Int
        var converString=String(converInt)
        StudentRolllbl.text = converString
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
