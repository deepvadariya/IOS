//
//  ViewController.swift
//  DemoCoreData
//
//  Created by student on 16/10/23.
//  Copyright © 2023 student. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    var appdelegate=UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var StudentRollNolbl: UITextField!
    @IBOutlet weak var StudentNamelbl: UITextField!
    @IBAction func AddStudentbtn(_ sender: Any) {
        
        var contex=appdelegate.persistentContainer.viewContext
        
        var StudentEntity=NSEntityDescription.entity(forEntityName: "Student", in: contex)
        
        let NewStudent=NSManagedObject(entity: StudentEntity!, insertInto: contex)
        
        NewStudent.setValue(StudentNamelbl.text, forKey: "name")
        NewStudent.setValue(Int(StudentRollNolbl.text!), forKey: "roll")
        
        do {
            try contex.save()
        } catch let Error as NSError {
            print(Error)
        }
        
    }
    @IBAction func DisplayPagebtn(_ sender: Any) {
        performSegue(withIdentifier: "WayToDisplayData", sender: self)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

