//
//  TableVC.swift
//  StudentDataDemo
//
//  Created by Vishal Narvani on 30/04/01.
//  Copyright © 2001 GLS. All rights reserved.
//

import UIKit
import CoreData

class TableVC: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var arrStudents = [NSManagedObject]()

    override func viewDidLoad() {
        super.viewDidLoad()
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do {
            arrStudents = try context.fetch(fetchReq)
        } catch let err as NSError {
            print(err)
        }


        // Do any additional setup after loading the view.
    }
  
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        print(indexPath.row)
        
        
        
        
       
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext

        context.delete(arrStudents[indexPath.row])
         arrStudents.remove(at: indexPath.row)
        
        do {
            try context.save()
        } catch let err as NSError {
            print(err)
        }

        
        tableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrStudents.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCell(withIdentifier: "MyTableCell") as! MyTableCell
        
        var singleStu = arrStudents[indexPath.row]
        cell.lblName.text = singleStu.value(forKey: "name") as! String?
        cell.lblRollNo.text = singleStu.value(forKey: "rollno") as! String?
        return cell
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
