//
//  DetailView.swift
//  StudentDataDemo
//
//  Created by Vishal Narvani on 30/04/01.
//  Copyright © 2001 GLS. All rights reserved.
//

import UIKit
import CoreData


class DetailView: UIViewController {
    @IBOutlet weak var lblName: UILabel!

    @IBOutlet weak var lblRollNo: UILabel!
    var arrStudents = [NSManagedObject]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do {
            arrStudents = try context.fetch(fetchReq)
        } catch let err as NSError {
            print(err)
        }
        
        var selectedStudent = arrStudents[appDel.selectedIndex]
        
        lblRollNo.text = selectedStudent.value(forKey: "rollno") as! String?
        lblName.text = selectedStudent.value(forKey: "name") as! String?


        // Do any additional setup after loading the view.
    }
    @IBAction func actionDelete(_ sender: Any) {
        
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        
        context.delete(arrStudents[appDel.selectedIndex])
        
        
        do {
            try context.save()
        } catch let err as NSError {
            
        }
        
        self.navigationController?.popViewController(animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
