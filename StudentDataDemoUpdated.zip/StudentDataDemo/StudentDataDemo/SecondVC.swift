

//
//  SecondVC.swift
//  StudentDataDemo
//
//  Created by Vishal Narvani on 29/04/01.
//  Copyright © 2001 GLS. All rights reserved.
//

import UIKit
import CoreData
class SecondVC: UIViewController,UICollectionViewDataSource,UICollectionViewDelegate {
    
    @IBOutlet weak var collView: UICollectionView!
    
var arrStudents = [NSManagedObject]()
    override func viewDidLoad() {
        super.viewDidLoad()
       
               // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {return arrStudents.count
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        appDel.selectedIndex = indexPath.row
        self.performSegue(withIdentifier: "detailView", sender: self)
    }
      func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
      {
        var cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCell", for: indexPath) as! MyCell
        
        var singleStu = arrStudents[indexPath.row]
        cell.lblName.text = singleStu.value(forKey: "name") as! String?
        cell.lblRollNo.text = singleStu.value(forKey: "rollno") as! String?
        
        return cell
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(_ animated: Bool) {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        
        let fetchReq = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do {
            arrStudents = try context.fetch(fetchReq)
        } catch let err as NSError {
            print(err)
        }

        collView.reloadData()
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
