//
//  MyCell.swift
//  StudentDataDemo
//
//  Created by Vishal Narvani on 29/04/01.
//  Copyright © 2001 GLS. All rights reserved.
//

import UIKit

class MyCell: UICollectionViewCell {
    @IBOutlet weak var lblRollNo: UILabel!
    @IBOutlet weak var lblName: UILabel!
    
}
