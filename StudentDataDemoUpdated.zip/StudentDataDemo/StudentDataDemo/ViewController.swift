//
//  ViewController.swift
//  StudentDataDemo
//
//  Created by Vishal Narvani on 29/04/01.
//  Copyright © 2001 GLS. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var txtFieldRollNo: UITextField!
    @IBOutlet weak var txtFieldNm: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        //------------- Insert --------------------
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func actionSave(_ sender: Any) {
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        let stuEntity = NSEntityDescription.entity(forEntityName: "Student", in: context)
        
        let newStudent = NSManagedObject(entity: stuEntity!, insertInto: context)
        
        newStudent.setValue(txtFieldNm.text, forKey: "name")
        newStudent.setValue(txtFieldRollNo.text, forKey: "rollno")
        
         
        do {
            try context.save()
        } catch let err as NSError {
            print(err)
        }
        
        
    }

}

